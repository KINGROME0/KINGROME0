# Hi I'm Achi Fernando&nbsp;<a href="Hey"><img src="https://raw.githubusercontent.com/TOXIC-DEVIL/TOXIC-DEVIL/TOXIC-DEVIL-OFFICIAL/media/Hi.gif" width="48px"></a>

<p align="center">
<img src= "https://camo.githubusercontent.com/71b837571c48af3aa60a73dbc9d5936aa359d78efbfa8a6743cbbbc16b80ef4d/68747470733a2f2f63646e2e646973636f72646170702e636f6d2f6174746163686d656e74732f3830353930323039333930363630383138362f3830353931333937323533353539303932322f74656e6f722e676966"/>
</p>
 
[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=&color=%2331F7EA&center=true&lines=WELCOME+TO+MY+GITHUB;HI%2CI+am+Ahci+Fernando;Github+Tool+Maker;Simple+Application+Developer;Subscribe;Join+Our+Groups;THANK+YOU+FOR+VISIT+MY+GITHUB)](https://git.io/typing-svg) <br> 

<p align="center"><img src="https://user-images.githubusercontent.com/49580304/110319833-47367180-7fc4-11eb-87a7-392509eca9d7.gif" alt="Bt">
 
<p align="center"><img src="https://user-images.githubusercontent.com/49580304/110318584-81067880-7fc2-11eb-8391-152d308e7f2b.gif" alt="Bt">


  
### KNOW MORE ABOUT ME>>>>
<p align="center"><a href="https://github.com/AchiyaCT"><img title="Alpha Achiya" src="https://github-readme-stats.vercel.app/api?username=AchiyaCT&show_icons=true&include_all_commits=true&theme=chartreuse-dark&cache_seconds=3200"></a>
</p>


<p align="center">
<a href="https://github.com/noob-hackers"><img title="noob-hackers" src="https://github-readme-stats.vercel.app/api/top-langs/?username=AchiyaCT&layout=compact"></a>
</p>


<p align="center"> <a href="Alpha Achiya"><img width="170px" height="24" src="https://komarev.com/ghpvc/?username=AchiyaCT&label=PROFILE%20VISITORS&color=green&style=flat-square" alt="Alpha Achiya" /></a> </p><br> 


<div align="center">
<p>&nbsp;<img align="center" src="https://github-readme-stats.vercel.app/api?username=AchiyaCT&show_icons=true&theme=nightowl" alt="Alpha Achiya" /></p>

<p>&nbsp;<img align="center" src="https://github-readme-stats.vercel.app/api/top-langs/?username=AchiyaCT&theme=algolia&layout=compact&langs_count=10&hide_border=true&show_icons=true" alt="Alpha Achiya"/></p></a><br> 

##

<details>
    <summary>&#127942 <b>GitHub Awards</b></summary><br/>

![Github Trophy](https://github-profile-trophy.vercel.app/?username=AchiyaCT)

</details>

##

<details>
    <summary>&#127942 <b>GitHub Activity (Public Data)</b></summary><br/>

![Metrics](https://metrics.lecoq.io/AchiyaCT?template=classic&followup=1&isocalendar=1&languages=1&isocalendar.duration=half-year&config.timezone=Asia/Colombo)

</details>

##

## Another Pin Project
<details>
  <summary>My New WhatsApp Project</summary>
   <a href="https://github.com/AchiyaCT/ALPHA">
    <img src="https://github-readme-stats.vercel.app/api/pin/?username=AchiyaCT&repo=ALPHA">
  </a>
</details>

  <!--
<details>
  <summary>My New WhatsApp Bot Project</summary>
   <a href="https://go">
    <img src="https://gzo">
  </a>
  </details>
  --!>
